<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Terapist Güncelle</h2>
                </div>
                <form action="<?php echo e(url('/definitions/reservations/therapist/update/'.$reservation_therapist->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="therapistId">Terapist</label>
                                <select class="form-control" name="therapistId" id="therapistId">
                                    <option value="<?php echo e($reservation_therapist->therapist->id); ?>" selected><?php echo e($reservation_therapist->therapist->name); ?></option>
                                    <?php $__currentLoopData = $therapists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $therapist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($therapist->id); ?>"><?php echo e($therapist->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="piece">Adeti</label>
                                <input type="number" class="form-control" id="piece" name="piece" placeholder="Adet" value="<?php echo e($reservation_therapist->piece); ?>" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-5 float-right">Güncelle <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/reservations/edit_therapist.blade.php ENDPATH**/ ?>