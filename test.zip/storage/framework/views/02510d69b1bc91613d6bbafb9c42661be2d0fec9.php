<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Hizmet Güncelle</h2>
                    <p class="float-right last-user">İşlem Yapan Son Kullanıcı: <?php echo e($service->user->name); ?></p>
                </div>
                <form action="<?php echo e(url('/definitions/services/update/'.$service->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="serviceName">Hizmet Adı</label>
                                <input type="text" class="form-control" id="serviceName" name="serviceName" placeholder="Hizmet Adı" value="<?php echo e($service->name); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="serviceCurrency">Hizmet Para Birimi</label>
                                <select id="serviceCurrency" name="serviceCurrency" class="form-control" required>
                                    <option value="<?php echo e($service->currency); ?>" @selected(true)><?php echo e($service->currency); ?></option>
                                    <option value="EUR">EURO</option>
                                    <option value="USD">USD</option>
                                    <option value="GBP">GBP</option>
                                    <option value="TL">TL</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="serviceCost">Hizmet Ücreti</label>
                                <input type="text" class="form-control" id="serviceCost" name="serviceCost" placeholder="Hizmet Ücreti" value="<?php echo e($service->cost); ?>" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-5 float-right">Güncelle <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/services/edit_service.blade.php ENDPATH**/ ?>