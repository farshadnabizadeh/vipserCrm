<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-danger mt-3" onclick="previousPage();"><i class="fa fa-chevron-left"></i> Önceki Sayfa</button>
            <div class="card p-3 mt-3">
                <div class="card-title">
                    <nav class="nav nav-borders">
                        <a class="nav-link active ms-0" href="<?php echo e(url('/definitions/reservations/edit/'.$reservation->id)); ?>"><i class="fa fa-user"></i> Rezervasyon Bilgileri</a>
                        <a class="nav-link" href="<?php echo e(url('/definitions/reservations/edit/'.$reservation->id.'?page=payments')); ?>"><i class="fa fa-money"></i> Ödeme Bilgileri <?php if(!$hasPaymentType): ?> <i class="fa fa-ban"></i> <?php else: ?> <i class="fa fa-check"></i> <?php endif; ?></a>
                        <a class="nav-link" href="<?php echo e(url('/definitions/reservations/edit/'.$reservation->id.'?page=comissions')); ?>"><i class="fa fa-percent"></i> Komisyon <?php if(!$hasComission): ?> <i class="fa fa-ban"></i> <?php else: ?> <i class="fa fa-check"></i> <?php endif; ?></a>
                    </nav>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <form action="<?php echo e(url('/definitions/reservations/update/'.$reservation->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label for="arrivalDate">Rezervasyon Tarihi</label>
                                                        <input type="text" class="form-control datepicker" id="editArrivalDate" name="reservationDate" placeholder="Rezervasyon Tarihi" value="<?php echo e($reservation->reservation_date); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label for="reservationTime">Rezervasyon Saati</label>
                                                        <input type="text" class="form-control" id="arrivalTime" name="reservationTime" placeholder="Rezervasyon Saati" maxlength="5" onkeypress="timeFormat(this)" value="<?php echo e($reservation->reservation_time); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <label for="totalCustomer">Toplam Müşteri</label>
                                                        <input type="number" class="form-control" id="totalCustomer" name="totalCustomer" placeholder="Toplam Müşteri" value="<?php echo e($reservation->total_customer); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <label for="sobId">Rezervasyon Kaynağı</label>
                                                        <select id="sobId" name="sourceId" class="form-control">
                                                            <option value="<?php echo e($reservation->source_id); ?>" selected><?php echo e($reservation->source->name); ?></option>
                                                            <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($source->id); ?>"><?php echo e($source->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <label for="note">Rezervasyon Notu</label>
                                                        <textarea class="form-control" name="note" id="note" placeholder="Rezervasyon Notu"><?php echo e($reservation->reservation_note); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-success mt-5 float-right update-page-btn">Güncelle <i class="fa fa-check" aria-hidden="true"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card mt-3 h-100">
                                    <div class="card-body">
                                        <h3 class="d-flex align-items-center mb-3">Hizmetler</h3>
                                        <button type="button" class="btn btn-primary float-right add-new-btn" data-toggle="modal" data-target="#addServiceModal"><i class="fa fa-plus"></i> Hizmet Ekle</button>
                                        <table class="table table-striped table-bordered nowrap dataTable" id="tableData">
                                            <thead>
                                                <tr>
                                                    <th>Bakım</th>
                                                    <th>Adeti</th>
                                                    <th>Islem</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $reservation->subServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($subService->name); ?></td>
                                                    <td><?php echo e($subService->piece); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('/definitions/reservations/service/edit/'.$subService->id)); ?>" class="btn btn-warning inline-popups remove-btn"><i class="fa fa-edit"></i> Güncelle</a>
                                                        <a href="<?php echo e(url('/definitions/reservations/service/destroy/'.$subService->id)); ?>" class="btn btn-danger remove-btn" onclick="return confirm('Silmek istediğinize emin misiniz?');"><i class="fa fa-trash"></i> Sil</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card mt-3 h-100">
                                    <div class="card-body">
                                        <h3 class="d-flex align-items-center mb-3">Terapistler</h3>
                                        <button type="button" class="btn btn-primary float-right add-new-btn" data-toggle="modal" data-target="#addTherapistModal"><i class="fa fa-plus"></i> Terapist Ekle</button>
                                        <table class="table table-striped table-bordered nowrap dataTable" id="tableTherapist">
                                            <thead>
                                                <tr>
                                                    <th>Terapist</th>
                                                    <th>Adeti</th>
                                                    <th>Islem</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $reservation->subTherapists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subTherapist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($subTherapist->name); ?></td>
                                                    <td><?php echo e($subTherapist->piece); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('/definitions/reservations/therapist/edit/'.$subTherapist->id)); ?>" class="btn btn-warning inline-popups remove-btn"><i class="fa fa-edit"></i> Güncelle</a>
                                                        <a href="<?php echo e(url('/definitions/reservations/therapist/destroy/'.$subTherapist->id)); ?>" class="btn btn-danger remove-btn" onclick="return confirm('Silmek istediğinize emin misiniz?');"><i class="fa fa-trash"></i> Sil</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addPaymentTypeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Yeni Ödeme Türü Ekle</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="reservation_id" value="<?php echo e($reservation->id); ?>">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="paymentType">Ödeme Türü</label>
                            <select class="form-control" id="paymentType" name="paymentType" required>
                                <option></option>
                                <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($payment_type->id); ?>"><?php echo e($payment_type->payment_type_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="paymentPrice">Ücret</label>
                            <input type="text" class="form-control" placeholder="Ücret" id="paymentPrice">
                        </div>
                    </div>
               </div>
               <button type="button" class="btn btn-success float-right" id="addPaymentTypetoReservationSave">Kaydet <i class="fa fa-check" aria-hidden="true"></i></button>
            </form>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Kapat</button>
         </div>
      </div>
   </div>
</div>

<div class="modal fade" id="addServiceModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Yeni Hizmet Ekle</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="reservation_id" value="<?php echo e($reservation->id); ?>">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="serviceId">Hizmet</label>
                            <select class="form-control" id="serviceId" name="serviceId" required>
                                <option></option>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="piece">Hizmet Adeti</label>
                            <input type="text" class="form-control" id="piece" placeholder="Hizmet Adeti">
                        </div>
                    </div>
               </div>
               <button type="button" class="btn btn-success float-right" id="addServicetoReservationSave">Kaydet <i class="fa fa-check" aria-hidden="true"></i></button>
            </form>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Kapat</button>
         </div>
      </div>
   </div>
</div>

<div class="modal fade" id="addTherapistModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Yeni Terapist Ekle</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="reservation_id" value="<?php echo e($reservation->id); ?>">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="therapistId">Terapist</label>
                            <select class="form-control" id="therapistId" name="therapistId" required>
                                <option></option>
                                <?php $__currentLoopData = $therapists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $therapist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($therapist->id); ?>"><?php echo e($therapist->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="piece">Kaç İş</label>
                            <input type="text" class="form-control" id="piece">
                        </div>
                    </div>
               </div>
               <button type="button" class="btn btn-success float-right" id="addTherapisttoReservationSave">Kaydet <i class="fa fa-check" aria-hidden="true"></i></button>
            </form>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Kapat</button>
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/reservations/edit_reservation.blade.php ENDPATH**/ ?>