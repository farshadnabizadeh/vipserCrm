<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Ödeme Türünü Güncelle</h2>
                </div>
                <form action="<?php echo e(url('/definitions/reservations/paymenttype/update/'.$reservation_payment_type->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="paymentTypeId">Ödeme Türü</label>
                                <select class="form-control" name="paymentTypeId" id="paymentTypeId">
                                    <option value="<?php echo e($reservation_payment_type->paymentType->id); ?>" selected><?php echo e($reservation_payment_type->paymentType->type_name); ?></option>
                                    <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($payment_type->id); ?>"><?php echo e($payment_type->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="paymentPrice">Ücret</label>
                                <input type="number" class="form-control" id="paymentPrice" name="paymentPrice" placeholder="Ücret" value="<?php echo e($reservation_payment_type->payment_price); ?>" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-5 float-right">Güncelle <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/reservations/edit_payment_type.blade.php ENDPATH**/ ?>