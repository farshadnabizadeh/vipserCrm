<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Rehber Komisyonunu Güncelle</h2>
                </div>
                <form action="<?php echo e(url('/definitions/reservations/guideComission/update/'.$guide_comission->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="guideId">Rehber</label>
                                <select class="form-control" name="guideId" id="guideId">
                                    <option value="<?php echo e($guide_comission->guide->id); ?>" selected><?php echo e($guide_comission->guide->name); ?></option>
                                    <?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($guide->id); ?>"><?php echo e($guide->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="comissionPrice">Verilen Komisyon Ücreti</label>
                                <input type="number" class="form-control" id="comissionPrice" name="comissionPrice" placeholder="Ücret" value="<?php echo e($guide_comission->comission_price); ?>">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-5 float-right">Güncelle <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/reservations/edit_guide_comission.blade.php ENDPATH**/ ?>