<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-danger mt-3" onclick="previousPage();"><i class="fa fa-chevron-left"></i> Önceki Sayfa</button>
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Müşteriyi Güncelle</h2>
                    <p class="float-right last-user">İşlem Yapan Son Kullanıcı: <?php echo e($customer->user->name); ?></p>
                </div>
                <form action="<?php echo e(url('/definitions/customers/update/'.$customer->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="customerName">Müşteri Adı</label>
                                <input type="text" class="form-control" id="customerName" name="customerNameSurname" placeholder="Müşteri Adı" value="<?php echo e($customer->name_surname); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="customerPhone">Müşteri Telefon Numarası</label>
                                <input type="text" class="form-control" id="phone_get" name="customerPhone" placeholder="Müşteri Telefon Numarası" value="<?php echo e($customer->phone); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="customerCountry">Ülkesi</label>
                                <input type="text" class="form-control" id="country_get" name="customerCountry" placeholder="Ülkesi" value="<?php echo e($customer->country); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="customerEmail">Email Adresi</label>
                                <input type="text" class="form-control" id="customerEmail" name="customerEmail" placeholder="Email Adresi" value="<?php echo e($customer->email); ?>">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-5 float-right">Güncelle <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/admin/customers/edit_customer.blade.php ENDPATH**/ ?>