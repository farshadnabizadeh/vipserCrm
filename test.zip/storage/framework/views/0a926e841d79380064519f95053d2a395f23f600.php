<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <div class="sidenav-header  align-items-center">
            <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                <img src="<?php echo e(asset('assets/img/catmamescitlogosiyah.png')); ?>" class="navbar-brand-img">
            </a>
        </div>
        <div class="navbar-inner">
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('home*') ? 'active' : ''); ?>" href="<?php echo e(url('/home')); ?>">
                            <i class="fa fa-pie-chart text-primary"></i>
                            <span class="nav-link-text">Arayüz</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show customers')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('definitions/customers*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/customers')); ?>">
                            <i class="fa fa-users text-primary"></i>
                            <span class="nav-link-text">Müşteriler</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show contactform')): ?>
                    <li class="nav-item <?php echo e(request()->is('definitions/bookings*') || request()->is('definitions/contactforms*') ? 'active' : ''); ?>">
                        <a class="nav-link" href="javascript:;">
                            <i class="fa fa-wpforms text-primary"></i>
                            <span class="nav-link-text">Formlar</span>
                            <i class="fa fa-caret-right sub-icon"></i>
                        </a>
                        <ul class="nav-item_sub">
                            <li>
                                <a class="<?php echo e(request()->is('definitions/contactforms*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/contactforms?startDate='.date("Y-m-d").'&endDate='.date("Y-m-d").'')); ?>">
                                    <span>İletişim Formları</span>
                                </a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/bookings') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/bookings?startDate='.date("Y-m-d").'&endDate='.date("Y-m-d").'')); ?>">
                                    <span>Rezervasyon Formları</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show reservation')): ?>
                    <li class="nav-item <?php echo e(request()->is('definitions/reservations/calendar*') ? 'active' : ''); ?>">
                        <a class="nav-link" href="javascript:;">
                            <i class="fa fa-calendar text-primary"></i>
                            <span class="nav-link-text">Takvimler</span>
                            <i class="fa fa-caret-right sub-icon"></i>
                        </a>
                        <ul class="nav-item_sub">
                            <li>
                                <a class="<?php echo e(request()->is('definitions/reservations/calendar*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/reservations/calendar')); ?>">
                                    <span>Rezervasyon Takvimi</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item <?php echo e(request()->is('definitions/formstatuses*') || request()->is('definitions/guides*') || request()->is('definitions/discounts*') || request()->is('definitions/hotels*') || request()->is('definitions/payment_types*') || request()->is('definitions/sources*') || request()->is('definitions/services*') || request()->is('definitions/therapists*') ? 'active' : ''); ?>">
                        <a class="nav-link" href="javascript:;">
                            <i class="fa fa-tasks text-primary"></i>
                            <span class="nav-link-text">Tanımlamalar</span>
                            <i class="fa fa-caret-right sub-icon"></i>
                        </a>
                        <ul class="nav-item_sub">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show form statuses')): ?>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/formstatuses*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/formstatuses')); ?>">
                                    <span>Form Durumları</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show discount')): ?>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/discounts*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/discounts')); ?>">
                                    <span>İndirimler</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show hotel')): ?>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/hotels*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/hotels')); ?>">
                                    <span>Oteller</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show payment type')): ?>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/payment_types*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/payment_types')); ?>">
                                    <span>Ödeme Türleri</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show sources')): ?>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/sources*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/sources')); ?>">
                                    <span>Rezervasyon Kaynakları</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show guides')): ?>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/guides*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/guides')); ?>">
                                    <span>Rehberler</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show services')): ?>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/services*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/services')); ?>">
                                    <span>Hizmetler</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show therapist')): ?>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/therapists*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/therapists')); ?>">
                                    <span>Terapistler</span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <li class="nav-item <?php echo e(request()->is('reports*') ? 'active' : ''); ?>">
                        <a class="nav-link" href="javascript:;">
                            <i class="fa fa-file-text text-primary"></i>
                            <span class="nav-link-text">Raporlar</span>
                            <i class="fa fa-caret-right sub-icon"></i>
                        </a>
                        <ul class="nav-item_sub">
                            <li>
                                <a class="<?php echo e(request()->is('reports/reservations*') ? 'active' : ''); ?>" href="<?php echo e(url('reports/reservations?startDate='.date("Y-m-d").'&endDate='.date("Y-m-d").'')); ?>">
                                    <span>Rezervasyon Raporu</span>
                                </a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->is('reports/payments*') ? 'active' : ''); ?>" href="<?php echo e(url('reports/payments?startDate='.date("Y-m-d").'&endDate='.date("Y-m-d").'')); ?>">
                                    <span>Ciro Raporu</span>
                                </a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->is('reports/comissions*') ? 'active' : ''); ?>" href="<?php echo e(url('reports/comissions?startDate='.date("Y-m-d").'&endDate='.date("Y-m-d").'')); ?>">
                                    <span>Komisyon Raporu</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item <?php echo e(request()->is('definitions/reservations/create*') || request()->is('definitions/reservations') ? 'active' : ''); ?>">
                        <a class="nav-link" href="javascript:;">
                            <i class="fa fa-check text-primary"></i>
                            <span class="nav-link-text">Rezervasyonlar</span>
                            <i class="fa fa-caret-right sub-icon"></i>
                        </a>
                        <ul class="nav-item_sub">
                            <li>
                                <a class="<?php echo e(request()->is('definitions/reservations/create*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/reservations/create')); ?>">
                                    <span>Yeni Rezervasyon</span>
                                </a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/reservations') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/reservations?startDate='.date("Y-m-d").'&endDate='.date("Y-m-d").'')); ?>">
                                    <span>Rezervasyon Listesi</span>
                                </a>
                            </li>

                        </ul>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show users')): ?>
                    <li class="nav-item <?php echo e(request()->is('definitions/users*') || request()->is('roles*') ? 'active' : ''); ?>">
                        <a class="nav-link" href="javascript:;">
                            <i class="fa fa-user text-primary"></i>
                            <span class="nav-link-text">Kullanıcılar</span>
                            <i class="fa fa-caret-right sub-icon"></i>
                        </a>
                        <ul class="nav-item_sub">
                            <li>
                                <a class="<?php echo e(request()->is('roles*') ? 'active' : ''); ?>" href="<?php echo e(url('/roles')); ?>">
                                    <span>Roller</span>
                                </a>
                            </li>
                            <li>
                                <a class="<?php echo e(request()->is('definitions/users*') ? 'active' : ''); ?>" href="<?php echo e(url('/definitions/users')); ?>">
                                    <span>Tüm Kullanıcılar</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
                <hr class="my-3">
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /home/enes/Desktop/works/catmamescithammam/crm/resources/views/layouts/menu.blade.php ENDPATH**/ ?>