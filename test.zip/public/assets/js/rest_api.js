var api_version = "1.0.0";
var args = [
    '%c %c %c Catma Mescit Hammam REST-TR v' + api_version + ' %c %c %c ',
    'background: #0cf300',
    'background: #00bc17',
    'color: #ffffff; background: #00711f;',
    'background: #00bc17',
    'background: #0cf300',
    'background: #00bc17'
];
console.log.apply(console, args);